Poszczególne algorytmy można przetestować w osobnych plikach (np. bubble_sort.py) lub uruchomić program test_all.py, który testuje wszystkie algorytmy.
W razie, gdyby coś nie działało tak jak zaplanowałem, mogę zmodyfikować kod.

- Arkadiusz Paterak