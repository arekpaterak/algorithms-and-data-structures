Poszczególne algorytmy można przetestować w osobnych plikach (np. quick_sort.py) lub uruchomić program test_all.py, który testuje wszystkie algorytmy.

- Arkadiusz Paterak